Sebastián Muñoz 202273534-1

Todos los archivos deben estar en la misma carpeta

El programa se complia con: make
El programa se corre con: make run, si no esta compilado el programa no correra
Se pueden eliminar los archivos compilados con: make clean
 