public interface ILevantar {
    public void Levantar(Pikinim cyan,Pikinim magenta,Pikinim amarillo);
}